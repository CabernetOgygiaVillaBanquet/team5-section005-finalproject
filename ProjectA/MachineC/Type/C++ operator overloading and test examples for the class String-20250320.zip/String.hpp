// String.hpp:
#pragma once
#ifndef STRING_HPP
#define STRING_HPP

#include <cstring>

/// Mutable non-null character string
class String
{
public:
    String();
    String(const char * c_str);
    String(const String & str);
    ~String();

    size_t get_len() const { return _len; }

    operator const char * () const { return _data; }
    const char *     c_str() const { return _data; }

    String & operator=(const char * c_str); // overloads assignment from C-string
    String & operator=(const String & str); // overloads assignment form String

    char & operator[](size_t index);  // overloads index for individual element access
    char operator[](size_t index) const;

    String operator+(char c) const;  // overloads concatenation with char
    friend String operator+(char c, const String & str);
    
    //friend String operator+(char c, const char * str); // Error. At least one argument must be class/struct type.

    String operator+(const char * c_str) const; // overloads concatenation with C-string
    String operator+(const String & str) const; // overloads concatenation with String

    String & operator+=(char c);
    String & operator+=(const char * c_str);
    String & operator+=(const String & str);

    String & operator++();  // prefix:  ++str
    String operator++(int); // postfix: str++

    bool operator==(const String & str) const; // String == String
    bool operator==(const char * c_str) const; // String == C-String
    bool operator!=(const String & str) const; // String != String
    bool operator!=(const char * c_str) const; // String != C-String

private:
    String(char * c_str);
    void delete_data();

private:
    char * _data;
    size_t _len;
};

// There is not need for a friend if can be implemented otherwise:
bool operator==(const char * c_str, const String & str);  // C-String == String
bool operator!=(const char * c_str, const String & str);  // C-String != String

#endif //STRING_HPP