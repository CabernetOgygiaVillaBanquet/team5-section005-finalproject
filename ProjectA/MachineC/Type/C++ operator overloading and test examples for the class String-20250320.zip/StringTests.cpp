#include "String.hpp"
#include <cassert>

void StringTests()
{
    String s0;
    assert(0 == s0.get_len());

    const String cs0;
    assert(0 == cs0.get_len());

    String s1{ "ABC" };
    assert(0 == strcmp(s1, "ABC"));
    assert(0 == strcmp(s1.c_str(), "ABC"));

    const String cs1{ "ABC" };
    assert(0 == strcmp(cs1, "ABC"));
    assert(0 == strcmp(cs1.c_str(), "ABC"));

    assert( 0  != s1[0]);
    assert('A' == s1[0]);
    assert('B' == s1[1]);
    assert('C' == s1[2]);

    assert('A' == cs1[0]);
    assert('B' == cs1[1]);
    assert('C' == cs1[2]);

    assert(0 == s1[20]);
    assert(0 == s1[-20]);

    assert('A' == cs1[0]);
    assert('\0' == cs1[20]);
    assert('\0' == cs1[-20]);

    String s2{ s1 };
    assert(0 == strcmp(s2, "ABC"));

    const String cs2{ s1 };
    assert(0 == strcmp(cs2, "ABC"));

    String s3;
    assert(0 == strcmp(s3 + '0', "0"));
    assert(0 == strcmp('0' + s3, "0"));

    const String cs3;
    assert(0 == strcmp(cs3 + '0', "0"));
    assert(0 == strcmp('0' + cs3, "0"));

    s3 = s2;
    assert(0 == strcmp(s3, "ABC"));

    //cs3 = s2; // Okay to be prohibited on constant

    s3 = "";
    assert(0 == strcmp(s3, ""));

    //cs3 = ""; // Okay to be prohibited on constant

    s3 = "123";
    assert(0 == strcmp(s3, "123"));

    assert(0 == strcmp(s3 + "", "123"));
    assert(0 == strcmp(s3 + "1", "1231"));
    assert(0 == strcmp(s3 + "12", "12312"));

    assert(0 == strcmp(cs3 + "1", "1"));

    assert(0 == strcmp(s2 + s3, "ABC123"));

    assert(0 == strcmp(cs2 + s3, "ABC123"));
    assert(0 == strcmp(cs2 + cs3, "ABC"));

    assert(0 == strcmp(s0 + s3, "123"));
    assert(0 == strcmp(s3 + s0, "123"));

    assert(0 == strcmp(s3 += 'D', "123D"));

    //assert(0 == strcmp(cs2 += 'D', "ABCD")); // Okay to be prohibited on constant

    s3 += s3;
    assert(0 == strcmp(s3, "123D123D"));

    s3 += nullptr;
    assert(0 == strcmp(s3, "123D123D"));

    s3 += "";
    assert(0 == strcmp(s3, "123D123D"));

    s3 += "555";
    assert(0 == strcmp(s3, "123D123D555"));

    String s4("A");
    assert(0 == strcmp(++s4, "B"));
    assert(0 == strcmp(s4++, "B"));
    assert(0 == strcmp(s4, "C"));

    const String cs4("A");
    //assert(0 == strcmp(++cs4, "B")); // Okay to be prohibited on constant
    //assert(0 == strcmp(cs4++, "B")); // Okay to be prohibited on constant

    assert(nullptr != s4);
    assert(nullptr != cs4);

    const String cs5{ "ABC" };
    assert(s2 == cs5);
    
    const String cs6{ "ABc" };
    assert(s2 != cs6);


    String s6{ "BCD" };
    assert(s6 != "");
    assert(s6 == "BCD");
    assert("BCD" == s6);
    
    String s5{ cs5 };
    assert(s6 == ++s5);

    String s7{ "QWERTY" };
    assert('W' == s7[1]);

    const String cs7{ s7 };

    s7[1] = 'S';
    assert("QSERTY" == s7);

    assert('W' == cs7[1]);
    //cs7[1] = 'S'; // Okay to be prohibited on constant
}

int main()
{
	StringTests();
	return 0;
}