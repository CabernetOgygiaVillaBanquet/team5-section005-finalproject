// String.cpp:
#include "String.hpp"
#include <iostream>

using namespace std;

// An internal (private) constructor to initialize data with passed pointer.
// Required to avoid memory leaks when the String is being constructed upon
// function exit, e.g., return new char[x];
String::String(char * c_str)
{
    //cout << "String(char * c_str) ctor\n";

    _len = (nullptr != c_str) ? strlen(c_str) : 0;

    // If _len == 0 then _data points to memory location of _len representing an empty string
    _data = (_len > 0) ? c_str : (char*)&_len;
}


String::String() 
{
	//cout << "String() ctor\n";

    _len = 0;
    _data = (char*)&_len;
}


String::String(const char * c_str)
{
    //cout << "String(const char * c_str) ctor\n";

    _len = (nullptr != c_str) ? strlen(c_str) : 0;

    if (_len > 0)
    {
        _data = new char[_len + 1];
        strncpy(_data, c_str, _len);
        _data[_len] = '\0';
    }
    else
    {
        //_len = 0;
        _data = (char*)&_len;
    }
}


String::String(const String & copy)
    : String((const char *)copy)  // C++11 constructor chaining
{
	//cout << "String(const String & copy) ctor\n";
}

void String::delete_data()
{
    if (nullptr != _data && (char*)&_len != _data)
        delete [] _data;
}

String::~String()
{
    //cout << "~String() dtor\n";

    delete_data();
}


char & String::operator[](size_t index)
{
    if (index < _len)
        return _data[index];

    // Not good idiom. Throw of exception is preferred
    static char voidchar{};
    return voidchar;
}


char String::operator[](size_t index) const
{
    // not a good idiom, throw of exception is better
    return (index < _len) ? _data[index] : '\0';
}


String & String::operator=(const char * c_str)
{
    if (nullptr != c_str) // check against null-assignment
    {
        delete_data();
        _len = strlen(c_str);
        if (_len > 0)
        {
            _data = new char[_len + 1];
            strncpy(_data, c_str, _len + 1);
        }
        else
        {
            _data = (char*)&_len;
        }
    }
    return *this; // modified self
}


String & String::operator=(const String & str)
{
    return /*this->*/operator=(str._data);  // DRY and reuse exiting function!
}


String String::operator+(char c) const
{
    auto tmp{ new char[_len + 2] };
    strncpy(tmp, _data, _len);
    tmp[_len] = c;
    tmp[_len + 1] = '\0';

    return tmp; // updated copy
}


String operator+(char c, const String & str)
{
    auto tmp{ new char[str._len + 2] };
    tmp[0] = c;
    strncpy(tmp + 1, str._data, str._len);
    tmp[str._len + 1] = '\0';

    return tmp; // updated copy
}


String String::operator+(const char * c_str) const
{
    if (nullptr == c_str) // check against null-assignment
        return *this;
    auto c_str_len{ strlen(c_str) };
    auto tmp{ new char[_len + c_str_len + 1] };
    strncpy(tmp, _data, _len);
    strncpy(tmp + _len, c_str, c_str_len);
    tmp[_len + c_str_len] = '\0';
    return tmp; // updated copy
}


String String::operator+(const String & str) const
{
    return operator+(str._data); // DRY and reuse exiting function!
}


String & String::operator+=(char c)
{
    auto tmp{ new char[_len + 2] };
    strncpy(tmp, _data, _len);
    tmp[_len] = c;
    delete_data();
    _data = tmp;
    _len++;
    _data[_len] = '\0';

    return *this; // modified self
}


String & String::operator+=(const char * c_str)
{
    if (nullptr != c_str) // check against null-concatenation
    {
        auto c_str_len{ strlen(c_str) };
        auto tmp{ new char[_len + c_str_len + 1] };
        strncpy(tmp, _data, _len);
        strncpy(tmp + _len, c_str, c_str_len);
        delete_data();
        _data = tmp;
        _len += c_str_len;
        _data[_len] = '\0';
    }
    return *this; // modified self
}


String & String::operator+=(const String & str)
{
    return operator+=(str._data);
}


String & String::operator++()
{
    for (auto i{ 0U }; i < _len; i++)
        _data[i]++;

    return *this;         // return modified self
}


String String::operator++(int)
{
    String res{ *this }; // save initial state

    for (auto i{ 0U }; i < _len; i++)
        _data[i]++;

    return res;           // must return initial state!
}


bool String::operator==(const char * c_str) const
{
    if (nullptr != c_str)
        return (0 == strncmp(_data, c_str, _len));
    else
        return _data == c_str;
}


bool operator==(const char * c_str, const String & str)
{
    return str.operator==(c_str);
}


bool String::operator==(const String & str) const
{
    return operator==(str._data); // alternative: str.operator==(_data)
}


bool String::operator!=(const char * c_str) const
{
    return !operator==(c_str);
}


bool String::operator!=(const String & str) const
{
    return !operator==(str._data);
}


bool operator!=(const char * c_str, const String & str)
{
    return !str.operator==(c_str);
}